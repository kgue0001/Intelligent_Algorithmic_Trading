Test Model: Notebook for testing model
Train Model: Notebook for training Model
csv: Contains data set(DJI.csv) and csvs that show trades: 
	- Filter coloumn 'actual_action'
	- After training and testing are done, this file should contain 2 csvs. 
		- after_training (training trades)
		- finalmodel_data (testing trades)
models file: saves trained and tested models. 